/**
 * Created by pengguanfa on 2017/10/25.
 * 扩展api配置
 */
window.FinChatConf = null
window.FinChatConf && window.FinChatConf.extApi && (window.FinChatExtApiConf = window.FinChatConf.extApi)
