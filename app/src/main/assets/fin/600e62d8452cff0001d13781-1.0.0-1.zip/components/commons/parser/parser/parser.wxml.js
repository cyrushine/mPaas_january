define("components/commons/parser/parser/parser.wxml.js", function(require, module, exports, window){
"use strict";(wx["webpackJsonp"]=wx["webpackJsonp"]||[]).push([["components/commons/parser/parser/parser.wxml"],{/***/"./src/components/commons/parser/parser/parser.wxml":/*!**********************************************************!*\
  !*** ./src/components/commons/parser/parser/parser.wxml ***!
  \**********************************************************/ /*! no static exports found */ /***/function srcComponentsCommonsParserParserParserWxml(module,exports,__webpack_require__){module.exports=__webpack_require__.p+"components/commons/parser/parser/parser.wxml";/***/}},[["./src/components/commons/parser/parser/parser.wxml","runtime"]]]);
});