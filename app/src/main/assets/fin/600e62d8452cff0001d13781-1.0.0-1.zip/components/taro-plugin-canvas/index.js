define("components/taro-plugin-canvas/index.js", function(require, module, exports, window){
"use strict";function _typeof2(obj){"@babel/helpers - typeof";if(typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"){_typeof2=function _typeof2(obj){return typeof obj;};}else{_typeof2=function _typeof2(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj;};}return _typeof2(obj);}(wx["webpackJsonp"]=wx["webpackJsonp"]||[]).push([["components/taro-plugin-canvas/index"],{/***/"./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js?!./src/components/taro-plugin-canvas/index.js?taro&type=script&parse=COMPONENT&":/*!**************************************************************************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js??ref--4-0!./src/components/taro-plugin-canvas?taro&type=script&parse=COMPONENT& ***!
  \**************************************************************************************************************************************************************/ /*! no static exports found */ /***/function node_modulesTarojsMiniRunnerDistLoadersWxTransformerLoaderJsSrcComponentsTaroPluginCanvasIndexJsTaroTypeScriptParseCOMPONENT(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _get=function get(object,property,receiver){if(object===null)object=Function.prototype;var desc=Object.getOwnPropertyDescriptor(object,property);if(desc===undefined){var parent=Object.getPrototypeOf(object);if(parent===null){return undefined;}else{return get(parent,property,receiver);}}else if("value"in desc){return desc.value;}else{var getter=desc.get;if(getter===undefined){return undefined;}return getter.call(receiver);}};var _class,_temp2;var _taroWeapp=__webpack_require__(/*! @tarojs/taro-weapp */"./node_modules/@tarojs/taro-weapp/index.js");var _taroWeapp2=_interopRequireDefault(_taroWeapp);var _propTypes=__webpack_require__(/*! prop-types */"./node_modules/prop-types/index.js");var _propTypes2=_interopRequireDefault(_propTypes);var _tools=__webpack_require__(/*! ./utils/tools */"./src/components/taro-plugin-canvas/utils/tools.js");var _draw=__webpack_require__(/*! ./utils/draw */"./src/components/taro-plugin-canvas/utils/draw.js");__webpack_require__(/*! ./index.css */"./src/components/taro-plugin-canvas/index.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{"default":obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(_typeof2(call)==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+_typeof2(superClass));}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var count=1;var CanvasDrawer=(_temp2=_class=function(_BaseComponent){_inherits(CanvasDrawer,_BaseComponent);function CanvasDrawer(){var _ref;var _temp,_this,_ret;_classCallCheck(this,CanvasDrawer);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=CanvasDrawer.__proto__||Object.getPrototypeOf(CanvasDrawer)).call.apply(_ref,[this].concat(args))),_this),_this.$usedState=["pxWidth","pxHeight","canvasId","debug","factor","pixelRatio","config"],_this.toPx=function(rpx,_int){var factor=arguments.length>2&&arguments[2]!==undefined?arguments[2]:_this.state.factor;if(_int){return parseInt(rpx*factor*_this.state.pixelRatio);}return rpx*factor*_this.state.pixelRatio;},_this.toRpx=function(px,_int2){var factor=arguments.length>2&&arguments[2]!==undefined?arguments[2]:_this.state.factor;if(_int2){return parseInt(px/factor);}return px/factor;},_this._downloadImageAndInfo=function(image,index,pixelRatio){return new Promise(function(resolve,reject){(0,_tools.downloadImageAndInfo)(image,index,_this.toRpx,pixelRatio).then(function(result){_this.drawArr.push(result);resolve();})["catch"](function(err){console.log(err);//reject(err);
});});},_this.downloadResource=function(_ref2){var _ref2$images=_ref2.images,images=_ref2$images===undefined?[]:_ref2$images,_ref2$pixelRatio=_ref2.pixelRatio,pixelRatio=_ref2$pixelRatio===undefined?1:_ref2$pixelRatio;var drawList=[];var imagesTemp=images;imagesTemp.forEach(function(image,index){return drawList.push(_this._downloadImageAndInfo(image,index,pixelRatio));});return Promise.all(drawList);},_this.downloadResourceTransit=function(){var config=_this.props.config;return new Promise(function(resolve,reject){if(config.images&&config.images.length>0){_this.downloadResource(config||{}).then(function(){resolve();})["catch"](function(e){console.log(e);reject(e);});}else{setTimeout(function(){resolve(1);},500);}});},_this.initCanvas=function(w,h,debug){return new Promise(function(resolve){_this.setState({pxWidth:_this.toPx(w),pxHeight:_this.toPx(h),debug:debug},resolve);});},_this.onCreate=function(){var _this$props=_this.props,onCreateFail=_this$props.onCreateFail,config=_this$props.config;// Taro.showLoading({ mask: true, title: '生成中...' });
return _this.downloadResourceTransit().then(function(){_this.create(config);})["catch"](function(err){// Taro.hideLoading();
// Taro.showToast({ icon: 'none', title: err.errMsg || '下载图片失败' });
console.error(err);if(!onCreateFail){console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateFail 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#fail');}onCreateFail&&_this.props.onCreateFail(err);});},_this.create=function(config){_this.ctx=_taroWeapp2["default"].createCanvasContext(_this.canvasId,_this.$scope);var height=(0,_tools.getHeight)(config);// 设置 pixelRatio
_this.setState({pixelRatio:config.pixelRatio||1});_this.initCanvas(config.width,height,config.debug).then(function(){try{// 设置画布底色
if(config.backgroundColor){_this.ctx.save();_this.ctx.setFillStyle(config.backgroundColor);_this.ctx.fillRect(0,0,_this.toPx(config.width),_this.toPx(height));_this.ctx.restore();}var _config$texts=config.texts,texts=_config$texts===undefined?[]:_config$texts,_config$blocks=config.blocks,blocks=_config$blocks===undefined?[]:_config$blocks,_config$lines=config.lines,lines=_config$lines===undefined?[]:_config$lines;var queue=_this.drawArr.concat(texts.map(function(item){item.type='text';item.zIndex=item.zIndex||0;return item;})).concat(blocks.map(function(item){item.type='block';item.zIndex=item.zIndex||0;return item;})).concat(lines.map(function(item){item.type='line';item.zIndex=item.zIndex||0;return item;}));// 按照顺序排序
queue.sort(function(a,b){return a.zIndex-b.zIndex;});queue.forEach(function(item){var drawOptions={ctx:_this.ctx,toPx:_this.toPx,toRpx:_this.toRpx};if(item.type==='image'){if(item.imgPath){(0,_draw.drawImage)(item,drawOptions);}}else if(item.type==='text'){(0,_draw.drawText)(item,drawOptions);}else if(item.type==='block'){(0,_draw.drawBlock)(item,drawOptions);}else if(item.type==='line'){(0,_draw.drawLine)(item,drawOptions);}});var res=_taroWeapp2["default"].getSystemInfoSync();var platform=res.platform;var time=0;if(platform==='android'){// 在安卓平台，经测试发现如果海报过于复杂在转换时需要做延时，要不然样式会错乱
time=300;}_this.ctx.draw(false,function(){setTimeout(function(){_this.getTempFile();},time);});}catch(error){console.log(error);}})["catch"](function(err){// Taro.showToast({ icon: 'none', title: err.errMsg || '生成失败' });
console.error(err);});},_this.getTempFile=function(otherOptions){var _this$props2=_this.props,onCreateSuccess=_this$props2.onCreateSuccess,onCreateFail=_this$props2.onCreateFail;var _this$state=_this.state,pxWidth=_this$state.pxWidth,pxHeight=_this$state.pxHeight;var rpxWidth=pxWidth*2;var rpxHeight=pxHeight*2;_taroWeapp2["default"].canvasToTempFilePath({width:rpxWidth,height:rpxHeight,destWidth:rpxWidth,destHeight:rpxHeight,canvasId:_this.canvasId,success:function success(result){if(!onCreateSuccess){console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateSuccess 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#success');}onCreateSuccess&&_this.props.onCreateSuccess({width:rpxWidth,height:rpxHeight,data:result});},fail:function fail(error){var errMsg=error.errMsg;if(errMsg==='canvasToTempFilePath:fail:create bitmap failed'){count+=1;if(count<=3){_this.getTempFile(otherOptions);}else{if(!onCreateFail){console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateFail 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#fail');}onCreateFail&&_this.props.onCreateFail(error);}}}},_this.$scope);},_this.customComponents=[],_temp),_possibleConstructorReturn(_this,_ret);}_createClass(CanvasDrawer,[{key:'_constructor',value:function _constructor(props){_get(CanvasDrawer.prototype.__proto__||Object.getPrototypeOf(CanvasDrawer.prototype),'_constructor',this).call(this,props);this.state={pxWidth:0,pxHeight:0,debug:false,factor:0,pixelRatio:1};var canvasId=props.canvasId;this.canvasId=canvasId||(0,_tools.randomString)(10);console.log('props => canvasId',this.canvasId);this.ctx=null;this.cache={};this.drawArr=[];this.$$refs=new _taroWeapp2["default"].RefsArray();}},{key:'componentWillMount',value:function componentWillMount(){var config=this.props.config;var height=(0,_tools.getHeight)(config);this.initCanvas(config.width,height,config.debug);}},{key:'componentDidMount',value:function componentDidMount(){var sysInfo=_taroWeapp2["default"].getSystemInfoSync();var screenWidth=sysInfo.screenWidth;this.setState({factor:screenWidth/750});this.onCreate();}},{key:'componentWillUnmount',value:function componentWillUnmount(){}/**
     * @description rpx => px 基础方法
     * @param { number } rpx - 需要转换的数值
     * @param { boolean} int - 是否为 int
     * @param { number } [factor = this.state.factor] - 转化因子
     * @returns { number }
     */ /**
     * @description px => rpx
     * @param { number } px - 需要转换的数值
     * @param { boolean} int - 是否为 int
     * @param { number } [factor = this.state.factor] - 转化因子
     * @returns { number }
     */ /**
     * @description 下载图片并获取图片信息
     * @param  {} image
     * @param  {} index
     */ /**
     * @param  {} images=[]
     */ /**
     * @param
     */ /**
     * @param  {} w
     * @param  {} h
     * @param  {} debug
     */ /**
     * @param  { boolean }
     */ /**
     * @param  { object } config
     */},{key:'_createData',value:function _createData(){this.__state=arguments[0]||this.state||{};this.__props=arguments[1]||this.props||{};var __isRunloopRef=arguments[2];var __prefix=this.$prefix;var canvasId=this.canvasId;var _state=this.__state,pxWidth=_state.pxWidth,pxHeight=_state.pxHeight,debug=_state.debug;if(pxWidth&&pxHeight){}Object.assign(this.__state,{canvasId:canvasId});return this.__state;}}]);return CanvasDrawer;}(_taroWeapp.Component),_class.$$events=[],_class.defaultProps={},_class.propTypes={config:_propTypes2["default"].object.isRequired,onCreateSuccess:_propTypes2["default"].func.isRequired,onCreateFail:_propTypes2["default"].func.isRequired},_class.$$componentPath="components/taro-plugin-canvas/index",_temp2);exports["default"]=CanvasDrawer;Component(__webpack_require__(/*! @tarojs/taro-weapp */"./node_modules/@tarojs/taro-weapp/index.js")["default"].createComponent(CanvasDrawer));/***/},/***/"./node_modules/file-loader/dist/cjs.js?name=[path][name].wxml&context=/Users/yangbin/work/finogeeks/workspace/mutilplactform/swan-mina/src!./node_modules/@tarojs/mini-runner/dist/loaders/miniTemplateLoader.js!./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js?!./src/components/taro-plugin-canvas/index.js?taro&type=template&parse=COMPONENT&":/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/file-loader/dist/cjs.js?name=[path][name].wxml&context=/Users/yangbin/work/finogeeks/workspace/mutilplactform/swan-mina/src!./node_modules/@tarojs/mini-runner/dist/loaders/miniTemplateLoader.js!./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js??ref--4-0!./src/components/taro-plugin-canvas?taro&type=template&parse=COMPONENT& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/ /*! no static exports found */ /***/function node_modulesFileLoaderDistCjsJsNamePathNameWxmlContextUsersYangbinWorkFinogeeksWorkspaceMutilplactformSwanMinaSrcNode_modulesTarojsMiniRunnerDistLoadersMiniTemplateLoaderJsNode_modulesTarojsMiniRunnerDistLoadersWxTransformerLoaderJsSrcComponentsTaroPluginCanvasIndexJsTaroTypeTemplateParseCOMPONENT(module,exports,__webpack_require__){module.exports=__webpack_require__.p+"components/taro-plugin-canvas/index.wxml";/***/},/***/"./node_modules/object-assign/index.js":/*!*********************************************!*\
  !*** ./node_modules/object-assign/index.js ***!
  \*********************************************/ /*! no static exports found */ /***/function node_modulesObjectAssignIndexJs(module,exports,__webpack_require__){"use strict";/*
object-assign
(c) Sindre Sorhus
@license MIT
*/ /* eslint-disable no-unused-vars */var getOwnPropertySymbols=Object.getOwnPropertySymbols;var hasOwnProperty=Object.prototype.hasOwnProperty;var propIsEnumerable=Object.prototype.propertyIsEnumerable;function toObject(val){if(val===null||val===undefined){throw new TypeError('Object.assign cannot be called with null or undefined');}return Object(val);}function shouldUseNative(){try{if(!Object.assign){return false;}// Detect buggy property enumeration order in older V8 versions.
// https://bugs.chromium.org/p/v8/issues/detail?id=4118
var test1=new String('abc');// eslint-disable-line no-new-wrappers
test1[5]='de';if(Object.getOwnPropertyNames(test1)[0]==='5'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test2={};for(var i=0;i<10;i++){test2['_'+String.fromCharCode(i)]=i;}var order2=Object.getOwnPropertyNames(test2).map(function(n){return test2[n];});if(order2.join('')!=='0123456789'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test3={};'abcdefghijklmnopqrst'.split('').forEach(function(letter){test3[letter]=letter;});if(Object.keys(Object.assign({},test3)).join('')!=='abcdefghijklmnopqrst'){return false;}return true;}catch(err){// We don't expect any of the above to throw, but better to be safe.
return false;}}module.exports=shouldUseNative()?Object.assign:function(target,source){var from;var to=toObject(target);var symbols;for(var s=1;s<arguments.length;s++){from=Object(arguments[s]);for(var key in from){if(hasOwnProperty.call(from,key)){to[key]=from[key];}}if(getOwnPropertySymbols){symbols=getOwnPropertySymbols(from);for(var i=0;i<symbols.length;i++){if(propIsEnumerable.call(from,symbols[i])){to[symbols[i]]=from[symbols[i]];}}}}return to;};/***/},/***/"./node_modules/prop-types/checkPropTypes.js":/*!***************************************************!*\
  !*** ./node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************/ /*! no static exports found */ /***/function node_modulesPropTypesCheckPropTypesJs(module,exports,__webpack_require__){"use strict";/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _typeof=typeof Symbol==="function"&&_typeof2(Symbol.iterator)==="symbol"?function(obj){return _typeof2(obj);}:function(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":_typeof2(obj);};var printWarning=function printWarning(){};{var ReactPropTypesSecret=__webpack_require__(/*! ./lib/ReactPropTypesSecret */"./node_modules/prop-types/lib/ReactPropTypesSecret.js");var loggedTypeFailures={};var has=Function.call.bind(Object.prototype.hasOwnProperty);printWarning=function printWarning(text){var message='Warning: '+text;if(typeof console!=='undefined'){console.error(message);}try{// --- Welcome to debugging React ---
// This error was thrown as a convenience so that you can use this stack
// to find the callsite that caused this warning to fire.
throw new Error(message);}catch(x){}};}/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */function checkPropTypes(typeSpecs,values,location,componentName,getStack){{for(var typeSpecName in typeSpecs){if(has(typeSpecs,typeSpecName)){var error;// Prop type validation may throw. In case they do, we don't want to
// fail the render phase where it didn't fail before. So we log it.
// After these have been cleaned up, we'll let them throw.
try{// This is intentionally an invariant that gets caught. It's the same
// behavior as without this statement except with a better message.
if(typeof typeSpecs[typeSpecName]!=='function'){var err=Error((componentName||'React class')+': '+location+' type `'+typeSpecName+'` is invalid; '+'it must be a function, usually from the `prop-types` package, but received `'+_typeof(typeSpecs[typeSpecName])+'`.');err.name='Invariant Violation';throw err;}error=typeSpecs[typeSpecName](values,typeSpecName,componentName,location,null,ReactPropTypesSecret);}catch(ex){error=ex;}if(error&&!(error instanceof Error)){printWarning((componentName||'React class')+': type specification of '+location+' `'+typeSpecName+'` is invalid; the type checker '+'function must return `null` or an `Error` but returned a '+(typeof error==='undefined'?'undefined':_typeof(error))+'. '+'You may have forgotten to pass an argument to the type checker '+'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and '+'shape all require an argument).');}if(error instanceof Error&&!(error.message in loggedTypeFailures)){// Only monitor this failure once because there tends to be a lot of the
// same error.
loggedTypeFailures[error.message]=true;var stack=getStack?getStack():'';printWarning('Failed '+location+' type: '+error.message+(stack!=null?stack:''));}}}}}/**
 * Resets warning cache when testing.
 *
 * @private
 */checkPropTypes.resetWarningCache=function(){{loggedTypeFailures={};}};module.exports=checkPropTypes;/***/},/***/"./node_modules/prop-types/factoryWithTypeCheckers.js":/*!************************************************************!*\
  !*** ./node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************/ /*! no static exports found */ /***/function node_modulesPropTypesFactoryWithTypeCheckersJs(module,exports,__webpack_require__){"use strict";/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _typeof=typeof Symbol==="function"&&_typeof2(Symbol.iterator)==="symbol"?function(obj){return _typeof2(obj);}:function(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":_typeof2(obj);};var ReactIs=__webpack_require__(/*! react-is */"./node_modules/react-is/index.js");var assign=__webpack_require__(/*! object-assign */"./node_modules/object-assign/index.js");var ReactPropTypesSecret=__webpack_require__(/*! ./lib/ReactPropTypesSecret */"./node_modules/prop-types/lib/ReactPropTypesSecret.js");var checkPropTypes=__webpack_require__(/*! ./checkPropTypes */"./node_modules/prop-types/checkPropTypes.js");var has=Function.call.bind(Object.prototype.hasOwnProperty);var printWarning=function printWarning(){};{printWarning=function printWarning(text){var message='Warning: '+text;if(typeof console!=='undefined'){console.error(message);}try{// --- Welcome to debugging React ---
// This error was thrown as a convenience so that you can use this stack
// to find the callsite that caused this warning to fire.
throw new Error(message);}catch(x){}};}function emptyFunctionThatReturnsNull(){return null;}module.exports=function(isValidElement,throwOnDirectAccess){/* global Symbol */var ITERATOR_SYMBOL=typeof Symbol==='function'&&Symbol.iterator;var FAUX_ITERATOR_SYMBOL='@@iterator';// Before Symbol spec.
/**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */function getIteratorFn(maybeIterable){var iteratorFn=maybeIterable&&(ITERATOR_SYMBOL&&maybeIterable[ITERATOR_SYMBOL]||maybeIterable[FAUX_ITERATOR_SYMBOL]);if(typeof iteratorFn==='function'){return iteratorFn;}}/**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */var ANONYMOUS='<<anonymous>>';// Important!
// Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
var ReactPropTypes={array:createPrimitiveTypeChecker('array'),bool:createPrimitiveTypeChecker('boolean'),func:createPrimitiveTypeChecker('function'),number:createPrimitiveTypeChecker('number'),object:createPrimitiveTypeChecker('object'),string:createPrimitiveTypeChecker('string'),symbol:createPrimitiveTypeChecker('symbol'),any:createAnyTypeChecker(),arrayOf:createArrayOfTypeChecker,element:createElementTypeChecker(),elementType:createElementTypeTypeChecker(),instanceOf:createInstanceTypeChecker,node:createNodeChecker(),objectOf:createObjectOfTypeChecker,oneOf:createEnumTypeChecker,oneOfType:createUnionTypeChecker,shape:createShapeTypeChecker,exact:createStrictShapeTypeChecker};/**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */ /*eslint-disable no-self-compare*/function is(x,y){// SameValue algorithm
if(x===y){// Steps 1-5, 7-10
// Steps 6.b-6.e: +0 != -0
return x!==0||1/x===1/y;}else{// Step 6.a: NaN == NaN
return x!==x&&y!==y;}}/*eslint-enable no-self-compare*/ /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */function PropTypeError(message){this.message=message;this.stack='';}// Make `instanceof Error` still work for returned errors.
PropTypeError.prototype=Error.prototype;function createChainableTypeChecker(validate){{var manualPropTypeCallCache={};var manualPropTypeWarningCount=0;}function checkType(isRequired,props,propName,componentName,location,propFullName,secret){componentName=componentName||ANONYMOUS;propFullName=propFullName||propName;if(secret!==ReactPropTypesSecret){if(throwOnDirectAccess){// New behavior only for users of `prop-types` package
var err=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");err.name='Invariant Violation';throw err;}else if(typeof console!=='undefined'){// Old behavior for people using React.PropTypes
var cacheKey=componentName+':'+propName;if(!manualPropTypeCallCache[cacheKey]&&// Avoid spamming the console because they are often not actionable except for lib authors
manualPropTypeWarningCount<3){printWarning("You are manually calling a React.PropTypes validation function for the `"+propFullName+'` prop on `'+componentName+'`. This is deprecated '+'and will throw in the standalone `prop-types` package. '+'You may be seeing this warning due to a third-party PropTypes '+'library. See https://fb.me/react-warning-dont-call-proptypes '+'for details.');manualPropTypeCallCache[cacheKey]=true;manualPropTypeWarningCount++;}}}if(props[propName]==null){if(isRequired){if(props[propName]===null){return new PropTypeError('The '+location+' `'+propFullName+'` is marked as required '+('in `'+componentName+'`, but its value is `null`.'));}return new PropTypeError('The '+location+' `'+propFullName+'` is marked as required in '+('`'+componentName+'`, but its value is `undefined`.'));}return null;}else{return validate(props,propName,componentName,location,propFullName);}}var chainedCheckType=checkType.bind(null,false);chainedCheckType.isRequired=checkType.bind(null,true);return chainedCheckType;}function createPrimitiveTypeChecker(expectedType){function validate(props,propName,componentName,location,propFullName,secret){var propValue=props[propName];var propType=getPropType(propValue);if(propType!==expectedType){// `propValue` being instance of, say, date/regexp, pass the 'object'
// check, but we can offer a more precise error message here rather than
// 'of type `object`'.
var preciseType=getPreciseType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+preciseType+'` supplied to `'+componentName+'`, expected ')+('`'+expectedType+'`.'));}return null;}return createChainableTypeChecker(validate);}function createAnyTypeChecker(){return createChainableTypeChecker(emptyFunctionThatReturnsNull);}function createArrayOfTypeChecker(typeChecker){function validate(props,propName,componentName,location,propFullName){if(typeof typeChecker!=='function'){return new PropTypeError('Property `'+propFullName+'` of component `'+componentName+'` has invalid PropType notation inside arrayOf.');}var propValue=props[propName];if(!Array.isArray(propValue)){var propType=getPropType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected an array.'));}for(var i=0;i<propValue.length;i++){var error=typeChecker(propValue,i,componentName,location,propFullName+'['+i+']',ReactPropTypesSecret);if(error instanceof Error){return error;}}return null;}return createChainableTypeChecker(validate);}function createElementTypeChecker(){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];if(!isValidElement(propValue)){var propType=getPropType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected a single ReactElement.'));}return null;}return createChainableTypeChecker(validate);}function createElementTypeTypeChecker(){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];if(!ReactIs.isValidElementType(propValue)){var propType=getPropType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected a single ReactElement type.'));}return null;}return createChainableTypeChecker(validate);}function createInstanceTypeChecker(expectedClass){function validate(props,propName,componentName,location,propFullName){if(!(props[propName]instanceof expectedClass)){var expectedClassName=expectedClass.name||ANONYMOUS;var actualClassName=getClassName(props[propName]);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+actualClassName+'` supplied to `'+componentName+'`, expected ')+('instance of `'+expectedClassName+'`.'));}return null;}return createChainableTypeChecker(validate);}function createEnumTypeChecker(expectedValues){if(!Array.isArray(expectedValues)){{if(arguments.length>1){printWarning('Invalid arguments supplied to oneOf, expected an array, got '+arguments.length+' arguments. '+'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).');}else{printWarning('Invalid argument supplied to oneOf, expected an array.');}}return emptyFunctionThatReturnsNull;}function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];for(var i=0;i<expectedValues.length;i++){if(is(propValue,expectedValues[i])){return null;}}var valuesString=JSON.stringify(expectedValues,function replacer(key,value){var type=getPreciseType(value);if(type==='symbol'){return String(value);}return value;});return new PropTypeError('Invalid '+location+' `'+propFullName+'` of value `'+String(propValue)+'` '+('supplied to `'+componentName+'`, expected one of '+valuesString+'.'));}return createChainableTypeChecker(validate);}function createObjectOfTypeChecker(typeChecker){function validate(props,propName,componentName,location,propFullName){if(typeof typeChecker!=='function'){return new PropTypeError('Property `'+propFullName+'` of component `'+componentName+'` has invalid PropType notation inside objectOf.');}var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected an object.'));}for(var key in propValue){if(has(propValue,key)){var error=typeChecker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret);if(error instanceof Error){return error;}}}return null;}return createChainableTypeChecker(validate);}function createUnionTypeChecker(arrayOfTypeCheckers){if(!Array.isArray(arrayOfTypeCheckers)){printWarning('Invalid argument supplied to oneOfType, expected an instance of array.');return emptyFunctionThatReturnsNull;}for(var i=0;i<arrayOfTypeCheckers.length;i++){var checker=arrayOfTypeCheckers[i];if(typeof checker!=='function'){printWarning("Invalid argument supplied to oneOfType. Expected an array of check functions, but received "+getPostfixForTypeWarning(checker)+' at index '+i+'.');return emptyFunctionThatReturnsNull;}}function validate(props,propName,componentName,location,propFullName){for(var i=0;i<arrayOfTypeCheckers.length;i++){var checker=arrayOfTypeCheckers[i];if(checker(props,propName,componentName,location,propFullName,ReactPropTypesSecret)==null){return null;}}return new PropTypeError('Invalid '+location+' `'+propFullName+'` supplied to '+('`'+componentName+'`.'));}return createChainableTypeChecker(validate);}function createNodeChecker(){function validate(props,propName,componentName,location,propFullName){if(!isNode(props[propName])){return new PropTypeError('Invalid '+location+' `'+propFullName+'` supplied to '+('`'+componentName+'`, expected a ReactNode.'));}return null;}return createChainableTypeChecker(validate);}function createShapeTypeChecker(shapeTypes){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type `'+propType+'` '+('supplied to `'+componentName+'`, expected `object`.'));}for(var key in shapeTypes){var checker=shapeTypes[key];if(!checker){continue;}var error=checker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret);if(error){return error;}}return null;}return createChainableTypeChecker(validate);}function createStrictShapeTypeChecker(shapeTypes){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type `'+propType+'` '+('supplied to `'+componentName+'`, expected `object`.'));}// We need to check all keys in case some are required but missing from
// props.
var allKeys=assign({},props[propName],shapeTypes);for(var key in allKeys){var checker=shapeTypes[key];if(!checker){return new PropTypeError('Invalid '+location+' `'+propFullName+'` key `'+key+'` supplied to `'+componentName+'`.'+'\nBad object: '+JSON.stringify(props[propName],null,'  ')+'\nValid keys: '+JSON.stringify(Object.keys(shapeTypes),null,'  '));}var error=checker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret);if(error){return error;}}return null;}return createChainableTypeChecker(validate);}function isNode(propValue){switch(typeof propValue==='undefined'?'undefined':_typeof(propValue)){case'number':case'string':case'undefined':return true;case'boolean':return!propValue;case'object':if(Array.isArray(propValue)){return propValue.every(isNode);}if(propValue===null||isValidElement(propValue)){return true;}var iteratorFn=getIteratorFn(propValue);if(iteratorFn){var iterator=iteratorFn.call(propValue);var step;if(iteratorFn!==propValue.entries){while(!(step=iterator.next()).done){if(!isNode(step.value)){return false;}}}else{// Iterator will provide entry [k,v] tuples rather than values.
while(!(step=iterator.next()).done){var entry=step.value;if(entry){if(!isNode(entry[1])){return false;}}}}}else{return false;}return true;default:return false;}}function isSymbol(propType,propValue){// Native Symbol.
if(propType==='symbol'){return true;}// falsy value can't be a Symbol
if(!propValue){return false;}// 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
if(propValue['@@toStringTag']==='Symbol'){return true;}// Fallback for non-spec compliant Symbols which are polyfilled.
if(typeof Symbol==='function'&&propValue instanceof Symbol){return true;}return false;}// Equivalent of `typeof` but with special handling for array and regexp.
function getPropType(propValue){var propType=typeof propValue==='undefined'?'undefined':_typeof(propValue);if(Array.isArray(propValue)){return'array';}if(propValue instanceof RegExp){// Old webkits (at least until Android 4.0) return 'function' rather than
// 'object' for typeof a RegExp. We'll normalize this here so that /bla/
// passes PropTypes.object.
return'object';}if(isSymbol(propType,propValue)){return'symbol';}return propType;}// This handles more types than `getPropType`. Only used for error messages.
// See `createPrimitiveTypeChecker`.
function getPreciseType(propValue){if(typeof propValue==='undefined'||propValue===null){return''+propValue;}var propType=getPropType(propValue);if(propType==='object'){if(propValue instanceof Date){return'date';}else if(propValue instanceof RegExp){return'regexp';}}return propType;}// Returns a string that is postfixed to a warning about an invalid type.
// For example, "undefined" or "of type array"
function getPostfixForTypeWarning(value){var type=getPreciseType(value);switch(type){case'array':case'object':return'an '+type;case'boolean':case'date':case'regexp':return'a '+type;default:return type;}}// Returns class name of the object, if any.
function getClassName(propValue){if(!propValue.constructor||!propValue.constructor.name){return ANONYMOUS;}return propValue.constructor.name;}ReactPropTypes.checkPropTypes=checkPropTypes;ReactPropTypes.resetWarningCache=checkPropTypes.resetWarningCache;ReactPropTypes.PropTypes=ReactPropTypes;return ReactPropTypes;};/***/},/***/"./node_modules/prop-types/index.js":/*!******************************************!*\
  !*** ./node_modules/prop-types/index.js ***!
  \******************************************/ /*! no static exports found */ /***/function node_modulesPropTypesIndexJs(module,exports,__webpack_require__){"use strict";/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */{var ReactIs=__webpack_require__(/*! react-is */"./node_modules/react-is/index.js");// By explicitly using `prop-types` you are opting into new development behavior.
// http://fb.me/prop-types-in-prod
var throwOnDirectAccess=true;module.exports=__webpack_require__(/*! ./factoryWithTypeCheckers */"./node_modules/prop-types/factoryWithTypeCheckers.js")(ReactIs.isElement,throwOnDirectAccess);}/***/},/***/"./node_modules/prop-types/lib/ReactPropTypesSecret.js":/*!*************************************************************!*\
  !*** ./node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************/ /*! no static exports found */ /***/function node_modulesPropTypesLibReactPropTypesSecretJs(module,exports,__webpack_require__){"use strict";/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ReactPropTypesSecret='SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';module.exports=ReactPropTypesSecret;/***/},/***/"./node_modules/react-is/cjs/react-is.development.js":/*!***********************************************************!*\
  !*** ./node_modules/react-is/cjs/react-is.development.js ***!
  \***********************************************************/ /*! no static exports found */ /***/function node_modulesReactIsCjsReactIsDevelopmentJs(module,exports,__webpack_require__){"use strict";/** @license React v16.12.0
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _typeof=typeof Symbol==="function"&&_typeof2(Symbol.iterator)==="symbol"?function(obj){return _typeof2(obj);}:function(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":_typeof2(obj);};{(function(){'use strict';Object.defineProperty(exports,'__esModule',{value:true});// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol=typeof Symbol==='function'&&Symbol["for"];var REACT_ELEMENT_TYPE=hasSymbol?Symbol["for"]('react.element'):0xeac7;var REACT_PORTAL_TYPE=hasSymbol?Symbol["for"]('react.portal'):0xeaca;var REACT_FRAGMENT_TYPE=hasSymbol?Symbol["for"]('react.fragment'):0xeacb;var REACT_STRICT_MODE_TYPE=hasSymbol?Symbol["for"]('react.strict_mode'):0xeacc;var REACT_PROFILER_TYPE=hasSymbol?Symbol["for"]('react.profiler'):0xead2;var REACT_PROVIDER_TYPE=hasSymbol?Symbol["for"]('react.provider'):0xeacd;var REACT_CONTEXT_TYPE=hasSymbol?Symbol["for"]('react.context'):0xeace;// TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?
var REACT_ASYNC_MODE_TYPE=hasSymbol?Symbol["for"]('react.async_mode'):0xeacf;var REACT_CONCURRENT_MODE_TYPE=hasSymbol?Symbol["for"]('react.concurrent_mode'):0xeacf;var REACT_FORWARD_REF_TYPE=hasSymbol?Symbol["for"]('react.forward_ref'):0xead0;var REACT_SUSPENSE_TYPE=hasSymbol?Symbol["for"]('react.suspense'):0xead1;var REACT_SUSPENSE_LIST_TYPE=hasSymbol?Symbol["for"]('react.suspense_list'):0xead8;var REACT_MEMO_TYPE=hasSymbol?Symbol["for"]('react.memo'):0xead3;var REACT_LAZY_TYPE=hasSymbol?Symbol["for"]('react.lazy'):0xead4;var REACT_FUNDAMENTAL_TYPE=hasSymbol?Symbol["for"]('react.fundamental'):0xead5;var REACT_RESPONDER_TYPE=hasSymbol?Symbol["for"]('react.responder'):0xead6;var REACT_SCOPE_TYPE=hasSymbol?Symbol["for"]('react.scope'):0xead7;function isValidElementType(type){return typeof type==='string'||typeof type==='function'||// Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
type===REACT_FRAGMENT_TYPE||type===REACT_CONCURRENT_MODE_TYPE||type===REACT_PROFILER_TYPE||type===REACT_STRICT_MODE_TYPE||type===REACT_SUSPENSE_TYPE||type===REACT_SUSPENSE_LIST_TYPE||(typeof type==='undefined'?'undefined':_typeof(type))==='object'&&type!==null&&(type.$$typeof===REACT_LAZY_TYPE||type.$$typeof===REACT_MEMO_TYPE||type.$$typeof===REACT_PROVIDER_TYPE||type.$$typeof===REACT_CONTEXT_TYPE||type.$$typeof===REACT_FORWARD_REF_TYPE||type.$$typeof===REACT_FUNDAMENTAL_TYPE||type.$$typeof===REACT_RESPONDER_TYPE||type.$$typeof===REACT_SCOPE_TYPE);}/**
     * Forked from fbjs/warning:
     * https://github.com/facebook/fbjs/blob/e66ba20ad5be433eb54423f2b097d829324d9de6/packages/fbjs/src/__forks__/warning.js
     *
     * Only change is we use console.warn instead of console.error,
     * and do nothing when 'console' is not supported.
     * This really simplifies the code.
     * ---
     * Similar to invariant but only logs a warning if the condition is not met.
     * This can be used to log issues in development environments in critical
     * paths. Removing the logging code for production environments will keep the
     * same logic and follow the same code paths.
     */var lowPriorityWarningWithoutStack=function lowPriorityWarningWithoutStack(){};{var printWarning=function printWarning(format){for(var _len=arguments.length,args=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){args[_key-1]=arguments[_key];}var argIndex=0;var message='Warning: '+format.replace(/%s/g,function(){return args[argIndex++];});if(typeof console!=='undefined'){console.warn(message);}try{// --- Welcome to debugging React ---
// This error was thrown as a convenience so that you can use this stack
// to find the callsite that caused this warning to fire.
throw new Error(message);}catch(x){}};lowPriorityWarningWithoutStack=function lowPriorityWarningWithoutStack(condition,format){if(format===undefined){throw new Error("`lowPriorityWarningWithoutStack(condition, format, ...args)` requires a warning message argument");}if(!condition){for(var _len2=arguments.length,args=new Array(_len2>2?_len2-2:0),_key2=2;_key2<_len2;_key2++){args[_key2-2]=arguments[_key2];}printWarning.apply(undefined,[format].concat(args));}};}var lowPriorityWarningWithoutStack$1=lowPriorityWarningWithoutStack;function typeOf(object){if((typeof object==='undefined'?'undefined':_typeof(object))==='object'&&object!==null){var $$typeof=object.$$typeof;switch($$typeof){case REACT_ELEMENT_TYPE:var type=object.type;switch(type){case REACT_ASYNC_MODE_TYPE:case REACT_CONCURRENT_MODE_TYPE:case REACT_FRAGMENT_TYPE:case REACT_PROFILER_TYPE:case REACT_STRICT_MODE_TYPE:case REACT_SUSPENSE_TYPE:return type;default:var $$typeofType=type&&type.$$typeof;switch($$typeofType){case REACT_CONTEXT_TYPE:case REACT_FORWARD_REF_TYPE:case REACT_LAZY_TYPE:case REACT_MEMO_TYPE:case REACT_PROVIDER_TYPE:return $$typeofType;default:return $$typeof;}}case REACT_PORTAL_TYPE:return $$typeof;}}return undefined;}// AsyncMode is deprecated along with isAsyncMode
var AsyncMode=REACT_ASYNC_MODE_TYPE;var ConcurrentMode=REACT_CONCURRENT_MODE_TYPE;var ContextConsumer=REACT_CONTEXT_TYPE;var ContextProvider=REACT_PROVIDER_TYPE;var Element=REACT_ELEMENT_TYPE;var ForwardRef=REACT_FORWARD_REF_TYPE;var Fragment=REACT_FRAGMENT_TYPE;var Lazy=REACT_LAZY_TYPE;var Memo=REACT_MEMO_TYPE;var Portal=REACT_PORTAL_TYPE;var Profiler=REACT_PROFILER_TYPE;var StrictMode=REACT_STRICT_MODE_TYPE;var Suspense=REACT_SUSPENSE_TYPE;var hasWarnedAboutDeprecatedIsAsyncMode=false;// AsyncMode should be deprecated
function isAsyncMode(object){{if(!hasWarnedAboutDeprecatedIsAsyncMode){hasWarnedAboutDeprecatedIsAsyncMode=true;lowPriorityWarningWithoutStack$1(false,"The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API.");}}return isConcurrentMode(object)||typeOf(object)===REACT_ASYNC_MODE_TYPE;}function isConcurrentMode(object){return typeOf(object)===REACT_CONCURRENT_MODE_TYPE;}function isContextConsumer(object){return typeOf(object)===REACT_CONTEXT_TYPE;}function isContextProvider(object){return typeOf(object)===REACT_PROVIDER_TYPE;}function isElement(object){return(typeof object==='undefined'?'undefined':_typeof(object))==='object'&&object!==null&&object.$$typeof===REACT_ELEMENT_TYPE;}function isForwardRef(object){return typeOf(object)===REACT_FORWARD_REF_TYPE;}function isFragment(object){return typeOf(object)===REACT_FRAGMENT_TYPE;}function isLazy(object){return typeOf(object)===REACT_LAZY_TYPE;}function isMemo(object){return typeOf(object)===REACT_MEMO_TYPE;}function isPortal(object){return typeOf(object)===REACT_PORTAL_TYPE;}function isProfiler(object){return typeOf(object)===REACT_PROFILER_TYPE;}function isStrictMode(object){return typeOf(object)===REACT_STRICT_MODE_TYPE;}function isSuspense(object){return typeOf(object)===REACT_SUSPENSE_TYPE;}exports.typeOf=typeOf;exports.AsyncMode=AsyncMode;exports.ConcurrentMode=ConcurrentMode;exports.ContextConsumer=ContextConsumer;exports.ContextProvider=ContextProvider;exports.Element=Element;exports.ForwardRef=ForwardRef;exports.Fragment=Fragment;exports.Lazy=Lazy;exports.Memo=Memo;exports.Portal=Portal;exports.Profiler=Profiler;exports.StrictMode=StrictMode;exports.Suspense=Suspense;exports.isValidElementType=isValidElementType;exports.isAsyncMode=isAsyncMode;exports.isConcurrentMode=isConcurrentMode;exports.isContextConsumer=isContextConsumer;exports.isContextProvider=isContextProvider;exports.isElement=isElement;exports.isForwardRef=isForwardRef;exports.isFragment=isFragment;exports.isLazy=isLazy;exports.isMemo=isMemo;exports.isPortal=isPortal;exports.isProfiler=isProfiler;exports.isStrictMode=isStrictMode;exports.isSuspense=isSuspense;})();}/***/},/***/"./node_modules/react-is/index.js":/*!****************************************!*\
  !*** ./node_modules/react-is/index.js ***!
  \****************************************/ /*! no static exports found */ /***/function node_modulesReactIsIndexJs(module,exports,__webpack_require__){"use strict";{module.exports=__webpack_require__(/*! ./cjs/react-is.development */"./node_modules/react-is/cjs/react-is.development.js");}/***/},/***/"./src/components/taro-plugin-canvas/index.css":/*!*****************************************************!*\
  !*** ./src/components/taro-plugin-canvas/index.css ***!
  \*****************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasIndexCss(module,exports,__webpack_require__){// extracted by mini-css-extract-plugin
/***/},/***/"./src/components/taro-plugin-canvas/index.js":/*!****************************************************!*\
  !*** ./src/components/taro-plugin-canvas/index.js ***!
  \****************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasIndexJs(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);/* harmony import */var _index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(/*! .?taro&type=template&parse=COMPONENT& */"./src/components/taro-plugin-canvas/index.js?taro&type=template&parse=COMPONENT&");/* harmony import */var _index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(/*! .?taro&type=script&parse=COMPONENT& */"./src/components/taro-plugin-canvas/index.js?taro&type=script&parse=COMPONENT&");/* harmony reexport (unknown) */for(var __WEBPACK_IMPORT_KEY__ in _index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_1__){if(__WEBPACK_IMPORT_KEY__!=='default')(function(key){__webpack_require__.d(__webpack_exports__,key,function(){return _index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_1__[key];});})(__WEBPACK_IMPORT_KEY__);}/***/},/***/"./src/components/taro-plugin-canvas/index.js?taro&type=script&parse=COMPONENT&":/*!*****************************************************************************!*\
  !*** ./src/components/taro-plugin-canvas?taro&type=script&parse=COMPONENT& ***!
  \*****************************************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasIndexJsTaroTypeScriptParseCOMPONENT(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);/* harmony import */var _node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(/*! -!../../../node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js??ref--4-0!.?taro&type=script&parse=COMPONENT& */"./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js?!./src/components/taro-plugin-canvas/index.js?taro&type=script&parse=COMPONENT&");/* harmony import */var _node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0___default=/*#__PURE__*/__webpack_require__.n(_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__);/* harmony reexport (unknown) */for(var __WEBPACK_IMPORT_KEY__ in _node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__){if(__WEBPACK_IMPORT_KEY__!=='default')(function(key){__webpack_require__.d(__webpack_exports__,key,function(){return _node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__[key];});})(__WEBPACK_IMPORT_KEY__);}/* harmony default export */__webpack_exports__["default"]=_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_script_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0___default.a;/***/},/***/"./src/components/taro-plugin-canvas/index.js?taro&type=template&parse=COMPONENT&":/*!*******************************************************************************!*\
  !*** ./src/components/taro-plugin-canvas?taro&type=template&parse=COMPONENT& ***!
  \*******************************************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasIndexJsTaroTypeTemplateParseCOMPONENT(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);/* harmony import */var _node_modules_file_loader_dist_cjs_js_name_path_name_wxml_context_Users_yangbin_work_finogeeks_workspace_mutilplactform_swan_mina_src_node_modules_tarojs_mini_runner_dist_loaders_miniTemplateLoader_js_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(/*! -!../../../node_modules/file-loader/dist/cjs.js?name=[path][name].wxml&context=/Users/yangbin/work/finogeeks/workspace/mutilplactform/swan-mina/src!../../../node_modules/@tarojs/mini-runner/dist/loaders/miniTemplateLoader.js!../../../node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js??ref--4-0!.?taro&type=template&parse=COMPONENT& */"./node_modules/file-loader/dist/cjs.js?name=[path][name].wxml&context=/Users/yangbin/work/finogeeks/workspace/mutilplactform/swan-mina/src!./node_modules/@tarojs/mini-runner/dist/loaders/miniTemplateLoader.js!./node_modules/@tarojs/mini-runner/dist/loaders/wxTransformerLoader.js?!./src/components/taro-plugin-canvas/index.js?taro&type=template&parse=COMPONENT&");/* harmony import */var _node_modules_file_loader_dist_cjs_js_name_path_name_wxml_context_Users_yangbin_work_finogeeks_workspace_mutilplactform_swan_mina_src_node_modules_tarojs_mini_runner_dist_loaders_miniTemplateLoader_js_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0___default=/*#__PURE__*/__webpack_require__.n(_node_modules_file_loader_dist_cjs_js_name_path_name_wxml_context_Users_yangbin_work_finogeeks_workspace_mutilplactform_swan_mina_src_node_modules_tarojs_mini_runner_dist_loaders_miniTemplateLoader_js_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__);/* harmony reexport (unknown) */for(var __WEBPACK_IMPORT_KEY__ in _node_modules_file_loader_dist_cjs_js_name_path_name_wxml_context_Users_yangbin_work_finogeeks_workspace_mutilplactform_swan_mina_src_node_modules_tarojs_mini_runner_dist_loaders_miniTemplateLoader_js_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__){if(__WEBPACK_IMPORT_KEY__!=='default')(function(key){__webpack_require__.d(__webpack_exports__,key,function(){return _node_modules_file_loader_dist_cjs_js_name_path_name_wxml_context_Users_yangbin_work_finogeeks_workspace_mutilplactform_swan_mina_src_node_modules_tarojs_mini_runner_dist_loaders_miniTemplateLoader_js_node_modules_tarojs_mini_runner_dist_loaders_wxTransformerLoader_js_ref_4_0_index_js_taro_type_template_parse_COMPONENT___WEBPACK_IMPORTED_MODULE_0__[key];});})(__WEBPACK_IMPORT_KEY__);}/***/},/***/"./src/components/taro-plugin-canvas/utils/draw.js":/*!*********************************************************!*\
  !*** ./src/components/taro-plugin-canvas/utils/draw.js ***!
  \*********************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasUtilsDrawJs(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};exports._drawRadiusRect=_drawRadiusRect;exports._getTextWidth=_getTextWidth;exports._drawSingleText=_drawSingleText;exports.drawText=drawText;exports.drawImage=drawImage;exports.drawLine=drawLine;exports.drawBlock=drawBlock;var _ext=__webpack_require__(/*! ../../../utils/ext */"./src/utils/ext.ts");var _ext2=_interopRequireDefault(_ext);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{"default":obj};}/**
 * @description 绘制圆角矩形
 * @param { object } drawData - 绘制数据
 * @param { number } drawData.x - 左上角x坐标
 * @param { number } drawData.y - 左上角y坐标
 * @param { number } drawData.w - 矩形的宽
 * @param { number } drawData.h - 矩形的高
 * @param { number } drawData.r - 圆角半径
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function _drawRadiusRect(drawData,drawOptions){var x=drawData.x,y=drawData.y,w=drawData.w,h=drawData.h,r=drawData.r;var ctx=drawOptions.ctx,toPx=drawOptions.toPx;var br=r/2;ctx.beginPath();ctx.moveTo(toPx(x+br),toPx(y));// 移动到左上角的点
ctx.lineTo(toPx(x+w-br),toPx(y));ctx.arc(toPx(x+w-br),toPx(y+br),toPx(br),2*Math.PI*0.75,2*Math.PI*1);ctx.lineTo(toPx(x+w),toPx(y+h-br));ctx.arc(toPx(x+w-br),toPx(y+h-br),toPx(br),0,2*Math.PI*0.25);ctx.lineTo(toPx(x+br),toPx(y+h));ctx.arc(toPx(x+br),toPx(y+h-br),toPx(br),2*Math.PI*0.25,2*Math.PI*0.5);ctx.lineTo(toPx(x),toPx(y+br));ctx.arc(toPx(x+br),toPx(y+br),toPx(br),2*Math.PI*0.5,2*Math.PI*0.75);}/**
 * @description 计算文本长度
 * @param { Array | Object } text 数组 或者 对象
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function _getTextWidth(text,drawOptions){var ctx=drawOptions.ctx,toPx=drawOptions.toPx,toRpx=drawOptions.toRpx;var texts=[];if(Object.prototype.toString.call(text)==='[object Object]'){texts.push(text);}else{texts=text;}var width=0;// eslint-disable-next-line no-shadow
texts.forEach(function(_ref){var fontSize=_ref.fontSize,text=_ref.text,_ref$marginLeft=_ref.marginLeft,marginLeft=_ref$marginLeft===undefined?0:_ref$marginLeft,_ref$marginRight=_ref.marginRight,marginRight=_ref$marginRight===undefined?0:_ref$marginRight;ctx.setFontSize(toPx(fontSize));width+=ctx.measureText(text).width+marginLeft+marginRight;});return toRpx(width);}/**
 * @description 渲染一段文字
 * @param { object } drawData - 绘制数据
 * @param { number } drawData.x - x坐标 rpx
 * @param { number } drawData.y - y坐标 rpx
 * @param { number } drawData.fontSize - 文字大小 rpx
 * @param { number } [drawData.color] - 颜色
 * @param { string } [drawData.baseLine] - 基线对齐方式 top| middle|bottom
 * @param { string } [drawData.textAlign='left'] - 对齐方式 left|center|right
 * @param { string } drawData.text - 当Object类型时，参数为 text 字段的参数，marginLeft、marginRight这两个字段可用
 * @param { number } [drawData.opacity=1] - 1为不透明，0为透明
 * @param { string } [drawData.textDecoration='none']
 * @param { number } [drawData.width] - 文字宽度 没有指定为画布宽度
 * @param { number } [drawData.lineNum=1] - 根据宽度换行，最多的行数
 * @param { number } [drawData.lineHeight=0] - 行高
 * @param { string } [drawData.fontWeight='normal'] - 'bold' 加粗字体，目前小程序不支持 100 - 900 加粗
 * @param { string } [drawData.fontStyle='normal'] - 'italic' 倾斜字体
 * @param { string } [drawData.fontFamily="sans-serif"] - 小程序默认字体为 'sans-serif', 请输入小程序支持的字体
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function _drawSingleText(drawData,drawOptions){var x=drawData.x,y=drawData.y,fontSize=drawData.fontSize,color=drawData.color,baseLine=drawData.baseLine,_drawData$textAlign=drawData.textAlign,textAlign=_drawData$textAlign===undefined?'left':_drawData$textAlign,text=drawData.text,_drawData$opacity=drawData.opacity,opacity=_drawData$opacity===undefined?1:_drawData$opacity,_drawData$textDecorat=drawData.textDecoration,textDecoration=_drawData$textDecorat===undefined?'none':_drawData$textDecorat,width=drawData.width,_drawData$lineNum=drawData.lineNum,lineNum=_drawData$lineNum===undefined?1:_drawData$lineNum,_drawData$lineHeight=drawData.lineHeight,lineHeight=_drawData$lineHeight===undefined?0:_drawData$lineHeight,_drawData$fontWeight=drawData.fontWeight,fontWeight=_drawData$fontWeight===undefined?'normal':_drawData$fontWeight,_drawData$fontStyle=drawData.fontStyle,fontStyle=_drawData$fontStyle===undefined?'normal':_drawData$fontStyle,_drawData$fontFamily=drawData.fontFamily,fontFamily=_drawData$fontFamily===undefined?'sans-serif':_drawData$fontFamily;var ctx=drawOptions.ctx,toPx=drawOptions.toPx,toRpx=drawOptions.toRpx;ctx.save();ctx.beginPath();ctx.font=fontStyle+' '+fontWeight+' '+toPx(fontSize,true)+'px '+fontFamily;ctx.setGlobalAlpha(opacity);// ctx.setFontSize(toPx(fontSize));
ctx.setFillStyle(color);ctx.setTextBaseline(baseLine);ctx.setTextAlign(textAlign);var textWidth=toRpx(ctx.measureText(text).width);var textArr=[];if(textWidth>width){// 文本宽度 大于 渲染宽度
var fillText='';var line=1;for(var i=0;i<=text.length-1;i++){// 将文字转为数组，一行文字一个元素
fillText=fillText+text[i];if(toRpx(ctx.measureText(fillText).width)>=width){if(line===lineNum){if(i!==text.length-1){fillText=fillText.substring(0,fillText.length-1)+'...';}}if(line<=lineNum){textArr.push(fillText);}fillText='';line++;}else{if(line<=lineNum){if(i===text.length-1){textArr.push(fillText);}}}}textWidth=width;}else{textArr.push(text);}if(textArr.length>0){textArr.forEach(function(item,index){if(item){ctx.fillText(item,toPx(x),toPx(y+(lineHeight||fontSize)*index));}});}ctx.restore();// textDecoration
if(textDecoration!=='none'){var lineY=y;if(textDecoration==='line-through'){// 目前只支持贯穿线
lineY=y;// 小程序画布baseLine偏移阈值
var threshold=5;// 根据baseLine的不同对贯穿线的Y坐标做相应调整
switch(baseLine){case'top':lineY+=fontSize/2+threshold;break;case'middle':break;case'bottom':lineY-=fontSize/2+threshold;break;default:lineY-=fontSize/2-threshold;break;}}ctx.save();ctx.moveTo(toPx(x),toPx(lineY));ctx.lineTo(toPx(x)+toPx(textWidth),toPx(lineY));ctx.setStrokeStyle(color);ctx.stroke();ctx.restore();}return textWidth;}/**
 * 渲染文字
 * @param { object } params - 绘制数据
 * @param { number } params.x - x坐标 rpx
 * @param { number } params.y - y坐标 rpx
 * @param { number } params.fontSize - 文字大小 rpx
 * @param { number } [params.color] - 颜色
 * @param { string } [params.baseLine] - 基线对齐方式 top| middle|bottom
 * @param { string } [params.textAlign='left'] - 对齐方式 left|center|right
 * @param { string } params.text - 当Object类型时，参数为 text 字段的参数，marginLeft、marginRight这两个字段可用
 * @param { number } [params.opacity=1] - 1为不透明，0为透明
 * @param { string } [params.textDecoration='none']
 * @param { number } [params.width] - 文字宽度 没有指定为画布宽度
 * @param { number } [params.lineNum=1] - 根据宽度换行，最多的行数
 * @param { number } [params.lineHeight=0] - 行高
 * @param { string } [params.fontWeight='normal'] - 'bold' 加粗字体，目前小程序不支持 100 - 900 加粗
 * @param { string } [params.fontStyle='normal'] - 'italic' 倾斜字体
 * @param { string } [params.fontFamily="sans-serif"] - 小程序默认字体为 'sans-serif', 请输入小程序支持的字体
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function drawText(params,drawOptions){// const { ctx, toPx, toRpx } = drawOptions;
var x=params.x,y=params.y,text=params.text,baseLine=params.baseLine;if(Object.prototype.toString.call(text)==='[object Array]'){var preText={x:x,y:y,baseLine:baseLine};text.forEach(function(item){preText.x+=item.marginLeft||0;var textWidth=_drawSingleText(Object.assign(item,_extends({},preText)),drawOptions);preText.x+=textWidth+(item.marginRight||0);// 下一段字的 x 轴为上一段字 x + 上一段字宽度
});}else{_drawSingleText(params,drawOptions);}}/**
 * @description 渲染图片
 * @param { object } data
 * @param { number } x - 图像的左上角在目标 canvas 上 x 轴的位置
 * @param { number } y - 图像的左上角在目标 canvas 上 y 轴的位置
 * @param { number } w - 在目标画布上绘制图像的宽度，允许对绘制的图像进行缩放
 * @param { number } h - 在目标画布上绘制图像的高度，允许对绘制的图像进行缩放
 * @param { number } sx - 源图像的矩形选择框的左上角 x 坐标
 * @param { number } sy - 源图像的矩形选择框的左上角 y 坐标
 * @param { number } sw - 源图像的矩形选择框的宽度
 * @param { number } sh - 源图像的矩形选择框的高度
 * @param { number } [borderRadius=0] - 圆角
 * @param { number } [borderWidth=0] - 边框
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function drawImage(data,drawOptions){var ctx=drawOptions.ctx,toPx=drawOptions.toPx;var imgPath=data.imgPath,x=data.x,y=data.y,w=data.w,h=data.h,sx=data.sx,sy=data.sy,sw=data.sw,sh=data.sh,_data$borderRadius=data.borderRadius,borderRadius=_data$borderRadius===undefined?0:_data$borderRadius,_data$borderWidth=data.borderWidth,borderWidth=_data$borderWidth===undefined?0:_data$borderWidth,borderColor=data.borderColor;ctx.save();if(borderRadius>0){var drawData={x:x,y:y,w:w,h:h,r:borderRadius};_drawRadiusRect(drawData,drawOptions);ctx.strokeStyle='rgba(255,255,255,0)';ctx.stroke();ctx.clip();if(_ext2["default"].BUILD_ENV==='swan'){ctx.drawImage(imgPath,toPx(x),toPx(y),toPx(w),toPx(h),toPx(sx),toPx(sy),toPx(sw),toPx(sh));}else{if(_ext2["default"].BUILD_ENV==='swan'){ctx.drawImage(imgPath,toPx(x),toPx(y),toPx(w),toPx(h),toPx(sx),toPx(sy),toPx(sw),toPx(sh));}else{ctx.drawImage(imgPath,toPx(sx),toPx(sy),toPx(sw),toPx(sh),toPx(x),toPx(y),toPx(w),toPx(h));}}if(borderWidth>0){ctx.setStrokeStyle(borderColor);ctx.setLineWidth(toPx(borderWidth));ctx.stroke();}}else{if(_ext2["default"].BUILD_ENV==='swan'){ctx.drawImage(imgPath,toPx(x),toPx(y),toPx(w),toPx(h),toPx(sx),toPx(sy),toPx(sw),toPx(sh));}else{ctx.drawImage(imgPath,toPx(sx),toPx(sy),toPx(sw),toPx(sh),toPx(x),toPx(y),toPx(w),toPx(h));}}ctx.restore();}/**
 * @description 渲染线
 * @param  { number } startX - 起始坐标
 * @param  { number } startY - 起始坐标
 * @param  { number } endX - 终结坐标
 * @param  { number } endY - 终结坐标
 * @param  { number } width - 线的宽度
 * @param  { string } [color] - 线的颜色
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function drawLine(drawData,drawOptions){var startX=drawData.startX,startY=drawData.startY,endX=drawData.endX,endY=drawData.endY,color=drawData.color,width=drawData.width;var ctx=drawOptions.ctx,toPx=drawOptions.toPx;ctx.save();ctx.beginPath();ctx.setStrokeStyle(color);ctx.setLineWidth(toPx(width));ctx.moveTo(toPx(startX),toPx(startY));ctx.lineTo(toPx(endX),toPx(endY));ctx.stroke();ctx.closePath();ctx.restore();}/**
 * @description 渲染块
 * @param  { number } x - x坐标
 * @param  { number } y - y坐标
 * @param  { number } height -高
 * @param  { string|object } [text] - 块里面可以填充文字，参考texts字段
 * @param  { number } [width=0] - 宽 如果内部有文字，由文字宽度和内边距决定
 * @param  { number } [paddingLeft=0] - 内左边距
 * @param  { number } [paddingRight=0] - 内右边距
 * @param  { number } [borderWidth] - 边框宽度
 * @param  { string } [backgroundColor] - 背景颜色
 * @param  { string } [borderColor] - 边框颜色
 * @param  { number } [borderRadius=0] - 圆角
 * @param  { number } [opacity=1] - 透明度
 *
 * @param { object } drawOptions - 绘制对象
 * @param { object } drawOptions.ctx - ctx对象
 * @param { function } drawOptions.toPx - toPx方法
 * @param { function } drawOptions.toRpx - toRpx方法
 */function drawBlock(_ref2,drawOptions){var text=_ref2.text,_ref2$width=_ref2.width,width=_ref2$width===undefined?0:_ref2$width,height=_ref2.height,x=_ref2.x,y=_ref2.y,_ref2$paddingLeft=_ref2.paddingLeft,paddingLeft=_ref2$paddingLeft===undefined?0:_ref2$paddingLeft,_ref2$paddingRight=_ref2.paddingRight,paddingRight=_ref2$paddingRight===undefined?0:_ref2$paddingRight,borderWidth=_ref2.borderWidth,backgroundColor=_ref2.backgroundColor,borderColor=_ref2.borderColor,_ref2$borderRadius=_ref2.borderRadius,borderRadius=_ref2$borderRadius===undefined?0:_ref2$borderRadius,_ref2$opacity=_ref2.opacity,opacity=_ref2$opacity===undefined?1:_ref2$opacity,_ref2$shadow=_ref2.shadow,shadow=_ref2$shadow===undefined?{}:_ref2$shadow;var ctx=drawOptions.ctx,toPx=drawOptions.toPx;// 判断是否块内有文字
var blockWidth=0;// 块的宽度
var textX=0;var textY=0;if(typeof text!=='undefined'){// 如果有文字并且块的宽度小于文字宽度，块的宽度为 文字的宽度 + 内边距
var textWidth=_getTextWidth(typeof text.text==='string'?text:text.text,drawOptions);blockWidth=textWidth>width?textWidth:width;blockWidth+=paddingLeft+paddingLeft;var _text$textAlign=text.textAlign,textAlign=_text$textAlign===undefined?'left':_text$textAlign;textY=height/2+y;// 文字的y轴坐标在块中线
if(textAlign==='left'){// 如果是右对齐，那x轴在块的最左边
textX=x+paddingLeft;}else if(textAlign==='center'){textX=blockWidth/2+x;}else{textX=x+blockWidth-paddingRight;}}else{blockWidth=width;}if(backgroundColor){// 画面
ctx.save();ctx.setGlobalAlpha(opacity);ctx.setFillStyle(backgroundColor);if(borderRadius>0){// 画圆角矩形
var drawData={x:x,y:y,w:blockWidth,h:height,r:borderRadius};_drawRadiusRect(drawData,drawOptions);ctx.fill();}else{ctx.fillRect(toPx(x),toPx(y),toPx(blockWidth),toPx(height));}ctx.restore();}if(borderWidth){// 画线
ctx.save();ctx.setGlobalAlpha(opacity);ctx.setStrokeStyle(borderColor);ctx.setLineWidth(toPx(borderWidth));if(borderRadius>0){// 画圆角矩形边框
var _drawData={x:x,y:y,w:blockWidth,h:height,r:borderRadius};_drawRadiusRect(_drawData,drawOptions);ctx.stroke();}else{ctx.strokeRect(toPx(x),toPx(y),toPx(blockWidth),toPx(height));}ctx.restore();}if(text){drawText(Object.assign(text,{x:textX,y:textY}),drawOptions);}if(typeof shadow!=='undefined'&&shadow.color){var _ref3=shadow||{},_ref3$offsetX=_ref3.offsetX,offsetX=_ref3$offsetX===undefined?0:_ref3$offsetX,_ref3$offsetY=_ref3.offsetY,offsetY=_ref3$offsetY===undefined?0:_ref3$offsetY,_ref3$color=_ref3.color,color=_ref3$color===undefined?'#000000':_ref3$color,_ref3$blur=_ref3.blur,blur=_ref3$blur===undefined?10:_ref3$blur,_ref3$opacity=_ref3.opacity,_opacity=_ref3$opacity===undefined?1:_ref3$opacity;ctx.save();try{ctx.setShadow(offsetX,offsetY,blur,color);}catch(error){ctx.shadowOffsetX=offsetX;ctx.shadowOffsetY=offsetY;ctx.shadowColor=color;ctx.shadowBlur=blur;console.log('DEBUG: setShadow => error',error);}ctx.setGlobalAlpha(_opacity);ctx.fillRect(toPx(x),toPx(y),toPx(blockWidth),toPx(height-10));ctx.restore();}}/***/},/***/"./src/components/taro-plugin-canvas/utils/tools.js":/*!**********************************************************!*\
  !*** ./src/components/taro-plugin-canvas/utils/tools.js ***!
  \**********************************************************/ /*! no static exports found */ /***/function srcComponentsTaroPluginCanvasUtilsToolsJs(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};exports.randomString=randomString;exports.getHeight=getHeight;exports.mapHttpToHttps=mapHttpToHttps;exports.downImage=downImage;exports.getImageInfo=getImageInfo;exports.downloadImageAndInfo=downloadImageAndInfo;var _taroWeapp=__webpack_require__(/*! @tarojs/taro-weapp */"./node_modules/@tarojs/taro-weapp/index.js");var _taroWeapp2=_interopRequireDefault(_taroWeapp);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{"default":obj};}/**
 * @description 生成随机字符串
 * @param  { number } length - 字符串长度
 * @returns { string }
 */function randomString(length){var str=Math.random().toString(36).substr(2);if(str.length>=length){return str.substr(0,length);}str+=randomString(length-str.length);return str;}/**
 * @description 获取最大高度
 * @param  {} config
 * @returns { number }
 */function getHeight(config){var getTextHeight=function getTextHeight(text){var fontHeight=text.lineHeight||text.fontSize;var height=0;if(text.baseLine==='top'){height=fontHeight;}else if(text.baseLine==='middle'){height=fontHeight/2;}else{height=0;}return height;};var heightArr=[];(config.blocks||[]).forEach(function(item){heightArr.push(item.y+item.height);});(config.texts||[]).forEach(function(item){var height=void 0;if(Object.prototype.toString.call(item.text)==='[object Array]'){item.text.forEach(function(i){height=getTextHeight(_extends({},i,{baseLine:item.baseLine}));heightArr.push(item.y+height);});}else{height=getTextHeight(item);heightArr.push(item.y+height);}});(config.images||[]).forEach(function(item){heightArr.push(item.y+item.height);});(config.lines||[]).forEach(function(item){heightArr.push(item.startY);heightArr.push(item.endY);});var sortRes=heightArr.sort(function(a,b){return b-a;});var canvasHeight=0;if(sortRes.length>0){canvasHeight=sortRes[0];}if(config.height<canvasHeight||!config.height){return canvasHeight;}else{return config.height;}}/**
 * 将http转为https
 * @param {String}} rawUrl 图片资源url
 * @returns { string }
 */function mapHttpToHttps(rawUrl){if(rawUrl.indexOf(':')<0){return rawUrl;}var urlComponent=rawUrl.split(':');if(urlComponent.length===2){if(urlComponent[0]==='http'){urlComponent[0]='https';return urlComponent[0]+':'+urlComponent[1];}}return rawUrl;}/**
 * 下载图片资源
 * @param { string } imageUrl
 * @returns  { Promise }
 */function downImage(imageUrl){var _ref=_taroWeapp2["default"].env||'',USER_DATA_PATH=_ref.USER_DATA_PATH;return new Promise(function(resolve,reject){if(/^http/.test(imageUrl)&&!new RegExp(USER_DATA_PATH).test(imageUrl)){// 支持临时图片和微信本地存储图片
if(imageUrl.indexOf('http://tmp')!==-1||imageUrl.indexOf('http://store')!==-1){resolve(imageUrl);}else{_taroWeapp2["default"].downloadFile({// url: (imageUrl),
// TODO
url:mapHttpToHttps(imageUrl),success:function success(res){if(res.statusCode===200){resolve(res.tempFilePath);}else{reject(res.errMsg);}},fail:function fail(err){reject(err);}});}}else{// 支持本地地址
resolve(imageUrl);}});}/**
 * 获取图片信息
 * @param {*} imgPath
 * @param {*} index
 * @returns  { Promise }
 */function getImageInfo(imgPath,index){return new Promise(function(resolve,reject){_taroWeapp2["default"].getImageInfo({src:imgPath,success:function success(res){resolve({imgPath:imgPath,imgInfo:res,index:index});},fail:function fail(err){console.log('获取图片信息失败==>',imgPath,index,err);resolve({imgPath:"",imgInfo:{errMsg:"getImageInfo:ok",path:""},index:index});//reject(err);
}})["catch"](function(error){console.log('ERROR Taro.getImageInfo',error);});});}/**
 * @description 下载图片并获取图片信息
 * @param  {} image
 * @param  {} index
 * @returns  { Promise }
 */function downloadImageAndInfo(image,index,toRpxFunc,pixelRatio){return new Promise(function(resolve,reject){var x=image.x,y=image.y,url=image.url,zIndex=image.zIndex;// 下载图片
downImage(url,index)// 获取图片信息
.then(function(imgPath){console.log('imgPath===>',imgPath);getImageInfo(imgPath,index).then(function(res){console.log('downImage====>',res,image);if(res){var _imgPath=res.imgPath,imgInfo=res.imgInfo;// 根据画布的宽高计算出图片绘制的大小，这里会保证图片绘制不变形
var sx=void 0;var sy=void 0;var borderRadius=image.borderRadius||0;var setWidth=image.width;var setHeight=image.height;var width=toRpxFunc(imgInfo.width/pixelRatio);var height=toRpxFunc(imgInfo.height/pixelRatio);if(width/height<=setWidth/setHeight){sx=0;sy=(height-width/setWidth*setHeight)/2;}else{sy=0;sx=(width-height/setHeight*setWidth)/2;}var result={type:'image',borderRadius:borderRadius,borderWidth:image.borderWidth,borderColor:image.borderColor,zIndex:typeof zIndex!=='undefined'?zIndex:index,imgPath:_imgPath,sx:sx,sy:sy,sw:width-sx*2,sh:height-sy*2,x:x,y:y,w:setWidth,h:setHeight};resolve(result);}else{reject(new Error('图片信息为空'));}})["catch"](function(err){console.log(err);reject(err);});})["catch"](function(error){console.log(error);reject(err);});});}/***/}},[["./src/components/taro-plugin-canvas/index.js","runtime","taro","vendors","common"]]]);
});